# GraphCNN-Bike

Data can be found here:

https://drive.google.com/file/d/1R2oHO5Dr7dMi7HUY0hpNJJju6Jt9JSVn/view?usp=sharing

